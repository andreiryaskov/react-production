export {
    ArticlesPageAsync as ArticlesPage,
} from './ui/ArticlesPage/ArticlesPage.async';
