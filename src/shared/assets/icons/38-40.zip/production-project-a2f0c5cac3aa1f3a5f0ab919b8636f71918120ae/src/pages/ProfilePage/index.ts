export {
    ProfilePageAsync as ProfilePage,
} from './ui/ProfilePage.async';
