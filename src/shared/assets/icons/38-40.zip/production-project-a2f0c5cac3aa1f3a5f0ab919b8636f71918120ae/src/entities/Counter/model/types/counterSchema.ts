export interface CounterSchema {
    value: number;
}
